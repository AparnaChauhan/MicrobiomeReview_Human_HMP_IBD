mbSet<-Init.mbSetObj()
mbSet<-SetModuleType(mbSet, "mdp")
mbSet<-ReadSampleTable(mbSet, "hmp2_metadata_modified_IBD_MicrobiomeAnalyst.csv");
mbSet<-Read16SAbundData(mbSet, "otu_table.v1.biom","biom","SILVA","F");
mbSet<-SanityCheckData(mbSet, "biom");
mbSet<-PlotLibSizeView(mbSet, "norm_libsizes_0","png");
mbSet<-CreatePhyloseqObj(mbSet, "biom","SILVA","F")
mbSet<-ApplyAbundanceFilter(mbSet, "prevalence", 4, 0.2);
mbSet<-ApplyVarianceFilter(mbSet, "sd", 0.1);
mbSet<-PerformNormalization(mbSet, "none", "none", "clr");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_0","Phylum","TreatmentGroup", "null", "barraw",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_1","Species","sex", "none", "barraw",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_2","Genus","sex", "none", "barraw",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_3","Genus","sex", "none", "barnorm",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_4","Genus","TreatmentGroup", "none", "barnorm",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_5","Genus","TreatmentGroup", "none", "barraw",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotOverallPieGraph(mbSet, "Phylum", 10,"sum", 10, "bottom");
GetSeriesColors()
mbSet<-SavePiechartImg(mbSet, "Phylum","primary_piechart_0","png");
mbSet<-PlotOverallPieGraph(mbSet, "Species", 5,"sum", 10, "bottom");
GetSeriesColors()
mbSet<-SavePiechartImg(mbSet, "Species","primary_piechart_1","png");
mbSet<-PlotOverallPieGraph(mbSet, "Genus", 5,"sum", 10, "bottom");
GetSeriesColors()
mbSet<-SavePiechartImg(mbSet, "Genus","primary_piechart_2","png");
mbSet<-PlotRarefactionCurve(mbSet, "filt","TreatmentGroup","TreatmentGroup","TreatmentGroup","5","rarefaction_curve_0","png");
mbSet<-PlotRarefactionCurve(mbSet, "filt","site_name","TreatmentGroup","TreatmentGroup","5","rarefaction_curve_1","png");
mbSet<-PlotRarefactionCurve(mbSet, "filt","sex","TreatmentGroup","TreatmentGroup","5","rarefaction_curve_2","png");
mbSet<-PrepareHeatTreePlot(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "ulcerative colitis_vs_Crohns disease", 0.05, "heat_tree_0","png");
mbSet<-PrepareHeatTreePlot(mbSet, "TreatmentGroup", "Genus", "dbgr", "dft", "ulcerative colitis_vs_Crohns disease", 0.05, "heat_tree_1","png");
mbSet<-PrepareHeatTreePlot(mbSet, "TreatmentGroup", "Genus", "dbgr", "dft", "ulcerative colitis_vs_non Inflammatory Bowel Disease", 0.05, "heat_tree_2","png");
mbSet<-PrepareHeatTreePlot(mbSet, "TreatmentGroup", "Genus", "dbgr", "dft", "Crohns disease_vs_non Inflammatory Bowel Disease", 0.05, "heat_tree_3","png");
mbSet<-PrepareHeatTreePlot(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "Crohns disease_vs_non Inflammatory Bowel Disease", 0.05, "heat_tree_4","png");
mbSet<-PrepareHeatTreePlot(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "ulcerative colitis_vs_non Inflammatory Bowel Disease", 0.05, "heat_tree_5","png");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_0","Chao1","TreatmentGroup","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_0","Chao1","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","TreatmentGroup");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_1","Chao1","TreatmentGroup","Species", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_1","Chao1","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","TreatmentGroup");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_2","Shannon","TreatmentGroup","Species", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_2","Shannon","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","TreatmentGroup");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_3","Simpson","TreatmentGroup","Species", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_3","Simpson","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","TreatmentGroup");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_4","Simpson","TreatmentGroup","Species", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_4","Simpson","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "nonpar","TreatmentGroup");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_5","Shannon","TreatmentGroup","Species", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_5","Shannon","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "nonpar","TreatmentGroup");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_6","Chao1","TreatmentGroup","Species", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_6","Chao1","TreatmentGroup","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "nonpar","TreatmentGroup");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_0","PCoA","bray","expfac","TreatmentGroup","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "PCoA","bray","OTU","expfac","TreatmentGroup","","Chao1","beta_diver3d_0.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","bray","TreatmentGroup");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_1","PCoA","bray","expfac","site_name","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "PCoA","bray","OTU","expfac","site_name","","Chao1","beta_diver3d_1.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","bray","site_name");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_2","PCoA","bray","expfac","diagnosis","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "PCoA","bray","OTU","expfac","diagnosis","","Chao1","beta_diver3d_2.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","bray","diagnosis");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_3","NMDS","bray","expfac","diagnosis","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "NMDS","bray","OTU","expfac","diagnosis","","Chao1","beta_diver3d_3.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","bray","diagnosis");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_4","NMDS","bray","expfac","TreatmentGroup","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "NMDS","bray","OTU","expfac","TreatmentGroup","","Chao1","beta_diver3d_4.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","bray","TreatmentGroup");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_5","NMDS","bray","expfac","site_name","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "NMDS","bray","OTU","expfac","site_name","","Chao1","beta_diver3d_5.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","bray","site_name");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_6","NMDS","jsd","expfac","site_name","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "NMDS","jsd","OTU","expfac","site_name","","Chao1","beta_diver3d_6.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","jsd","site_name");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_7","NMDS","jaccard","expfac","site_name","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "NMDS","jaccard","OTU","expfac","site_name","","Chao1","beta_diver3d_7.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","jaccard","site_name");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_8","NMDS","jaccard","expfac","TreatmentGroup","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "NMDS","jaccard","OTU","expfac","TreatmentGroup","","Chao1","beta_diver3d_8.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","jaccard","TreatmentGroup");
mbSet<-PerformBetaDiversity(mbSet, "beta_diver_9","PCoA","jaccard","expfac","TreatmentGroup","none","OTU","","Chao1", "yes", "png", 72, "default");
mbSet<-PCoA3D.Anal(mbSet, "PCoA","jaccard","OTU","expfac","TreatmentGroup","","Chao1","beta_diver3d_9.json")
mbSet<-PerformCategoryComp(mbSet, "OTU", "adonis","jaccard","TreatmentGroup");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_0",0.2,0.01,"OTU","bwm","overview", "all_samples", "TreatmentGroup", "null", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_1",0.2,0.01,"OTU","bwm","overview", "all_samples", "TreatmentGroup", "Crohns disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_2",0.2,0.01,"OTU","bwm","overview", "all_samples", "TreatmentGroup", "non Inflammatory Bowel Disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_3",0.2,0.01,"OTU","bwm","overview", "all_samples", "TreatmentGroup", "ulcerative colitis", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_4",0.2,0.01,"Species","bwm","overview", "all_samples", "TreatmentGroup", "ulcerative colitis", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_5",0.2,0.01,"Genus","bwm","overview", "all_samples", "TreatmentGroup", "ulcerative colitis", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_6",0.2,0.01,"Genus","bwm","overview", "all_samples", "TreatmentGroup", "non Inflammatory Bowel Disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_7",0.2,0.01,"Genus","bwm","overview", "all_samples", "TreatmentGroup", "Crohns disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_8",0.2,0.01,"Genus","bwm","overview", "all_samples", "TreatmentGroup", "non Inflammatory Bowel Disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_9",0.2,0.01,"Species","bwm","overview", "all_samples", "TreatmentGroup", "ulcerative colitis", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_10",0.2,0.01,"Species","bwm","overview", "all_samples", "TreatmentGroup", "Crohns disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_11",0.2,0.01,"OTU","bwm","overview", "all_samples", "TreatmentGroup", "non Inflammatory Bowel Disease", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_12",0.2,0.01,"OTU","bwm","overview", "all_samples", "TreatmentGroup", "ulcerative colitis", "png");
mbSet<-PlotHeatmap(mbSet, "heatmap_0","euclidean","ward.D","bwm","TreatmentGroup","OTU","overview","F", "png","T","F");
mbSet<-PlotHeatmap(mbSet, "heatmap_1","euclidean","ward.D","bwm","TreatmentGroup","Species","overview","F", "png","T","F");
mbSet<-PlotHeatmap(mbSet, "heatmap_2","euclidean","ward.D","bwm","TreatmentGroup","Genus","overview","F", "png","T","F");
mbSet<-PlotTreeGraph(mbSet, "plot_tree_0","bray","ward.D","TreatmentGroup","OTU", "default", "png");
mbSet<-PlotTreeGraph(mbSet, "plot_tree_1","bray","ward.D","TreatmentGroup","Species", "default", "png");
mbSet<-PlotTreeGraph(mbSet, "plot_tree_2","bray","ward.D","TreatmentGroup","Genus", "default", "png");
mbSet<-PrepareCorrExpValues(mbSet, "TreatmentGroup", "Phylum", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Phylum", "sparcc", "expr",100, 0.05, 0.3, "mean", "cor_net_0.json")
mbSet<-PrepareCorrExpValues(mbSet, "TreatmentGroup", "Phylum", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Phylum", "pearson", "expr",100, 0.05, 0.3, "mean", "cor_net_1.json")
mbSet<-PrepareCorrExpValues(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Species", "pearson", "expr",100, 0.05, 0.3, "mean", "cor_net_2.json")
mbSet<-PrepareCorrExpValues(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Species", "sparcc", "expr",100, 0.05, 0.3, "mean", "cor_net_3.json")
mbSet<-PrepareCorrExpValues(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Species", "spearman", "expr",100, 0.05, 0.3, "mean", "cor_net_4.json")
mbSet<-PrepareCorrExpValues(mbSet, "TreatmentGroup", "Species", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Species", "kendall", "expr",100, 0.05, 0.3, "mean", "cor_net_5.json")
mbSet<-Match.Pattern(mbSet, "pearson", "1-2-3", "OTU", "TreatmentGroup")
mbSet<-PlotCorr(mbSet, "ptn_0", "png", width=NA)
mbSet<-Match.Pattern(mbSet, "pearson", "1-2-3", "Species", "TreatmentGroup")
mbSet<-PlotCorr(mbSet, "ptn_1", "png", width=NA)
mbSet<-Match.Pattern(mbSet, "pearson", "1-2-3", "Genus", "TreatmentGroup")
mbSet<-PlotCorr(mbSet, "ptn_2", "png", width=NA)
mbSet<-PerformUnivarTest(mbSet, "TreatmentGroup",0.05,"NA","OTU","tt");
mbSet<-PerformUnivarTest(mbSet, "TreatmentGroup",0.05,"NA","OTU","nonpar");
mbSet<-PerformUnivarTest(mbSet, "TreatmentGroup",0.05,"NA","Species","nonpar");
mbSet<-PerformUnivarTest(mbSet, "TreatmentGroup",0.05,"NA","Species","tt");
mbSet<-PerformUnivarTest(mbSet, "TreatmentGroup",0.05,"NA","Genus","tt");
mbSet<-PerformUnivarTest(mbSet, "TreatmentGroup",0.05,"NA","Genus","nonpar");
mbSet<-PerformMetagenomeSeqAnal(mbSet, "TreatmentGroup",0.05,"NA","OTU","zigfit");
mbSet<-PerformMetagenomeSeqAnal(mbSet, "TreatmentGroup",0.05,"NA","Species","zigfit");
mbSet<-PerformMetagenomeSeqAnal(mbSet, "TreatmentGroup",0.05,"NA","Genus","zigfit");
mbSet<-PerformRNAseqDE(mbSet, "EdgeR",0.05,"TreatmentGroup","NA","OTU");
mbSet<-PerformRNAseqDE(mbSet, "EdgeR",0.05,"TreatmentGroup","NA","Species");
mbSet<-PerformRNAseqDE(mbSet, "EdgeR",0.05,"TreatmentGroup","NA","Genus");
mbSet<-PerformRNAseqDE(mbSet, "DESeq2",0.05,"TreatmentGroup","NA","Genus");
mbSet<-PerformRNAseqDE(mbSet, "DESeq2",0.05,"TreatmentGroup","NA","Species");
mbSet<-PerformRNAseqDE(mbSet, "DESeq2",0.05,"TreatmentGroup","NA","OTU");
mbSet<-PerformRNAseqDE(mbSet, "DESeq2",0.05,"TreatmentGroup","NA","OTU");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 2.0,  "TreatmentGroup","F","NA","OTU");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_0","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 2.0,  "TreatmentGroup","F","NA","OTU");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_1","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "TreatmentGroup","F","NA","OTU");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_2","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "TreatmentGroup","F","NA","Species");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_3","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "TreatmentGroup","F","NA","Genus");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_4","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 3.0,  "TreatmentGroup","F","NA","Genus");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_5","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "TreatmentGroup","F","NA","Genus");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_6","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "TreatmentGroup","F","NA","Family");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_7","png");
mbSet<-RF.Anal(mbSet, 500,7,1,"TreatmentGroup","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_0","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_0","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,10,1,"TreatmentGroup","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_1","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_1","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,10,1,"TreatmentGroup","Species")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_2","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_2","png", width=NA)
mbSet<-RF.Anal(mbSet, 1000,10,1,"TreatmentGroup","Species")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_3","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_3","png", width=NA)
mbSet<-RF.Anal(mbSet, 1000,20,1,"TreatmentGroup","Species")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_4","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_4","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,40,1,"TreatmentGroup","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_5","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_5","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,40,1,"site_name","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_6","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_6","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,20,1,"site_name","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_7","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_7","png", width=NA)
mbSet<-RF.Anal(mbSet, 1000,20,1,"site_name","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_8","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_8","png", width=NA)
mbSet<-RF.Anal(mbSet, 2000,20,1,"site_name","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_9","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_9","png", width=NA)
mbSet<-RF.Anal(mbSet, 1000,20,1,"site_name","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_10","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_10","png", width=NA)
mbSet<-Perform16FunAnot(mbSet, "SILVA","qi_silva");
mbSet<-Perform16FunAnot(mbSet, "SILVA","qi_silva");
